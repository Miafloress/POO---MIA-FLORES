package Mia;

public class Triangulo extends Figura {

    @Override
    public double calcularArea() {
        return (base * altura) / 2;
    }
}