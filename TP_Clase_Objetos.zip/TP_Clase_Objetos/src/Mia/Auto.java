package Mia;

public class Auto {

    private String marca;
    private String modelo;
    private String color;

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getMarca() {
        return marca;
    }

    public String getModelo() {
        return modelo;
    }

    public String getColor() {
        return color;
    }

    public void mostrarDatos() {
        System.out.println("Tengo un " + marca
                + " modelo " + modelo
                + " de color " + color);
    }
}