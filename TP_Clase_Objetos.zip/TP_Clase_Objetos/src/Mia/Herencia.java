package Mia;

public class Herencia {

    public static void main(String[] args) {

        // EJERCICIO 1: PERSONA

        Persona p1 = new Persona();
        p1.setNombre("Mia");
        p1.setEdad(17);

        Persona p2 = new Persona();
        p2.setNombre("Juan");
        p2.setEdad(20);

        System.out.println("PERSONAS");
        System.out.println(p1.getNombre() + " - " + p1.getEdad());
        System.out.println(p2.getNombre() + " - " + p2.getEdad());


        // EJERCICIO 2: LIBRO

        Libro l1 = new Libro("Harry Potter", "J.K. Rowling", 1997);
        Libro l2 = new Libro("El Principito", "Antoine de Saint-Exupéry", 1943);

        System.out.println("\nLIBROS");
        System.out.println(l1.getTitulo() + " - " + l1.getAutor() + " - " + l1.getAño());
        System.out.println(l2.getTitulo() + " - " + l2.getAutor() + " - " + l2.getAño());


        // EJERCICIO 3: AUTO

        Auto a1 = new Auto();
        a1.setMarca("Toyota");
        a1.setModelo("Corolla");
        a1.setColor("Negro");

        Auto a2 = new Auto();
        a2.setMarca("Ford");
        a2.setModelo("Focus");
        a2.setColor("Blanco");

        Auto a3 = new Auto();
        a3.setMarca("Fiat");
        a3.setModelo("Cronos");
        a3.setColor("Rojo");

        System.out.println("\nAUTOS");
        a1.mostrarDatos();
        a2.mostrarDatos();
        a3.mostrarDatos();


        // EJERCICIO 4: CUENTA BANCARIA

        CuentaBancaria cuenta = new CuentaBancaria();

        cuenta.setSaldo(50000);

        System.out.println("\nCUENTA BANCARIA");
        System.out.println("Saldo actual: $" + cuenta.getSaldo());


        // EJERCICIO 5: FIGURAS

        Triangulo t1 = new Triangulo();

        t1.setBase(10);
        t1.setAltura(5);

        System.out.println("\nTRIANGULO");
        System.out.println("Base: " + t1.getBase());
        System.out.println("Altura: " + t1.getAltura());
        System.out.println("Area: " + t1.calcularArea());


        Rectangulo r1 = new Rectangulo();

        r1.setBase(10);
        r1.setAltura(5);

        System.out.println("\nRECTANGULO");
        System.out.println("Base: " + r1.getBase());
        System.out.println("Altura: " + r1.getAltura());
        System.out.println("Area: " + r1.calcularArea());

    }
}