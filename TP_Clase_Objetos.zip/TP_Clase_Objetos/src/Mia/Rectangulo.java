package Mia;

public class Rectangulo extends Figura {

    @Override
    public double calcularArea() {
        return base * altura;
    }
}