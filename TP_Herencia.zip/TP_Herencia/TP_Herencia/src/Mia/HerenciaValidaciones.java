package Mia;

public class HerenciaValidaciones {

    public static void main(String[] args) {



        Empleado e1 = new Empleado("Mia", 17, 500000);

        System.out.println("EMPLEADO");
        e1.mostrarDatos();


       
        Auto a1 = new Auto("Toyota", "Corolla", 4);

        System.out.println("\nAUTO");
        a1.mostrarDatos();



        Perro p1 = new Perro("Toby", 3, "Caniche");

        System.out.println("\nPERRO");
        System.out.println("Nombre: " + p1.getNombre());
        System.out.println("Edad: " + p1.getEdad());
        System.out.println("Raza: " + p1.getRaza());

        p1.ladrar();

    }
}