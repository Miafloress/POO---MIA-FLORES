package Mia;

public class Auto extends Vehiculo {

    private int cant_Puertas;

    public Auto(String marca, String modelo, int cant_Puertas) {
        super(marca, modelo);
        this.cant_Puertas = cant_Puertas;
    }

    public void setCantPuertas(int cant_Puertas) {
        this.cant_Puertas = cant_Puertas;
    }

    public int getCantPuertas() {
        return cant_Puertas;
    }

    public void mostrarDatos() {
        System.out.println("Marca: " + getMarca());
        System.out.println("Modelo: " + getModelo());
        System.out.println("Cantidad de puertas: " + getCantPuertas());
    }
}